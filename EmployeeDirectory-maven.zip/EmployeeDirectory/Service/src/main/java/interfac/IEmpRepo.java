package interfac;

import java.util.List;

import com.employee.entity.Employee;

public interface IEmpRepo<T, Y> {

	void AddDetails(T t);

	List<T> getDetails();

	void UpdateDetails(Y y);

	public void deleteDetails(Y y);
	
	public List<Employee> search();

}

