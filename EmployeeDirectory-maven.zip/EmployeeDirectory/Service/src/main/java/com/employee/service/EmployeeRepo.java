package com.employee.service;
import interfac.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.employee.entity.Employee;


public class EmployeeRepo implements IEmpRepo<Employee, Integer> {

	List<Employee> l1 = new ArrayList<Employee>();
    List<Employee> s=new ArrayList();
	@Override
	public void AddDetails(Employee e) {
		l1.add(e);
	}

	@Override
	public List<Employee> getDetails() {
		return l1;
	}

	public void deleteDetails(Integer id) {
		for (Employee employee : l1) {
			if (employee.getId() == id) {
				l1.remove(employee);
				break;
			}
		}
	}

	@Override
	public void UpdateDetails(Integer id) {
		for (Employee employee : l1) {
			if (employee.getId() == id) {
				int ch;
				do {
					Scanner objScan = new Scanner(System.in);
					System.out.println("Press 1 to Update Name");
					System.out.println("Press 2 to Update Age");
					System.out.println("Press 3 to Update Id");
					System.out.println("Press 4 to Exit ");
                      
					System.out.println("Enter the Choice you want to update");

					ch = objScan.nextInt();
					switch (ch) {
					case 1: {
						System.out.println("Enter name:");
						String name = objScan.next();
						employee.setName(name);
						System.out.println("Name Updated Successfully");
						break;
					}
					case 2: {
						System.out.println("Enter age:");
						int age = objScan.nextInt();
						employee.setAge(age);
						System.out.println("Age Updated Successfully");

						break;
					}

					case 3: {
						System.out.println("Enter id:");
						id = objScan.nextInt();
						employee.setId(id);
						System.out.println("Id Updated Successfully");

						break;
					}

					case 4:
						break;

					default:
						System.out.println("Incorrect Choice");
					}
					break;

				} while (ch <= 3 && ch > 0);
			}

		}
	}

	@Override
	public List<Employee> search() {
		Scanner objScanner=new Scanner(System.in);
		System.out.println("Enter Employee Id to Search");
		int ssid=objScanner.nextInt();
	for(Employee employee:l1) {
		if(employee.getId()==ssid) {
			s.clear();
			s.add(employee);
			break;
		}
		
	}
	
		System.out.println("Record Not Found");
	
		return s;
	}
	
	
}
