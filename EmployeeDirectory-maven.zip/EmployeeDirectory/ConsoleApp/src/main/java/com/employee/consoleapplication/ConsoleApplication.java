package com.employee.consoleapplication;

import java.util.Scanner;

import com.employee.entity.Employee;
import com.employee.service.EmployeeRepo;
import interfac.*;

public class ConsoleApplication {

	public static void main(String[] args) {
		
		Scanner obScan = new Scanner(System.in);
		int ch;
		IEmpRepo<Employee, Integer> obj = new EmployeeRepo();
		Employee emp1 = new Employee("Nikhil", 22, 101);
		Employee emp2 = new Employee("Sonakshi", 23, 401);
		Employee emp3 = new Employee("Monu", 25, 301);
		Employee emp4 = new Employee("Rahul", 43, 201);

		obj.AddDetails(emp1);
		obj.AddDetails(emp2);
		obj.AddDetails(emp3);
		obj.AddDetails(emp4);

		do {
			System.out.println("Press 1 To Add Employee");
			System.out.println("Press 2 To Get Employee Details");
			System.out.println("Press 3 To Update Employee Details");
			System.out.println("Press 4 To Delete Employee");
			System.out.println("Press 5 To Search Employee");
			System.out.println("Press 6 To Exit");

			System.out.println("Enter Your Choice");
			ch = obScan.nextInt();

			switch (ch) {

			case 1:
				System.out.println("Enter  Employee Name");
				String ename = obScan.next();
				System.out.println("Enter Employee Age");
				int eage = obScan.nextInt();
				System.out.println("Enter Employee ID");
				int eid = obScan.nextInt();
				Employee obe = new Employee(ename, eage, eid);
				obj.AddDetails(obe);
				System.out.println("Congrats! Employee Added Successfully");

				System.out.println(obj.getDetails());

				break;

			case 2:
				System.out.println(obj.getDetails());
				break;

			case 3:
				System.out.println(obj.getDetails());

				System.out.println("Enter the Id of the Employee to update");
				int uid = obScan.nextInt();
				obj.UpdateDetails(uid);
				System.out.println(obj.getDetails());
				break;

			case 4:
				System.out.println(obj.getDetails());

				System.out.println("Enter the Id of the Employee to Delete");
				int did = obScan.nextInt();
				obj.deleteDetails(did);
				System.out.println(obj.getDetails());
				break;

			case 5:System.out.println(obj.search());
				break;

			case 6:
				break;

			default:
				System.out.println("Wrong choice");

			}

		} while (ch > 0 && ch <= 5);

	}

}
